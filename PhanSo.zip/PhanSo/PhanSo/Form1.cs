﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhanSo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btThucHien_Click(object sender, EventArgs e)
        {
            PhanSo ps = new PhanSo(Convert.ToInt32(tbA.Text), Convert.ToInt32(tbB.Text));
            if (cbPhepTinh.Text == "Cộng")
            {
                listBox1.Items.Add(tbA.Text + "/" + tbB.Text + " + " + tbC.Text + "/" + tbD.Text + " = " + ps.RutGon(ps.Cong(Convert.ToInt32(tbC.Text), Convert.ToInt32(tbD.Text))) );
            }
            else if (cbPhepTinh.Text == "Nhân")
            {
                listBox1.Items.Add(tbA.Text + "/" + tbB.Text + " x " + tbC.Text + "/" + tbD.Text + " = " + ps.RutGon(ps.Nhan(Convert.ToInt32(tbC.Text), Convert.ToInt32(tbD.Text))));
            }
        }
    }
}
