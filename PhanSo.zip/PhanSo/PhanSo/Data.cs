﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhanSo
{
    public class Data
    {
        private int a, b;

        public Data(int a, int b)
        {
            this.A = a;
            this.B = b;
        }

        public int A { get { return a; } set { a = value; } }
        public int B { get { return b; } set { b = value; } }

        public int UCLN(int a, int b)
        {
            if (b == 0) return a;
            return UCLN(b, a % b);
        }
    }
}
