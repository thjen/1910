﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhanSo
{
    public class PhanSo : Data
    {
        private int a, b;

        public PhanSo(int a, int b) : base(a, b)
        {
            this.a = a;
            this.b = b;
        }

        public string RutGon(string ps)
        {
            var checkUCLN = base.UCLN(Convert.ToInt32(ps.Split('/')[0]), Convert.ToInt32(ps.Split('/')[1]));
            if (checkUCLN == 1) return ps;
            return Convert.ToInt32(ps.Split('/')[0]) / base.UCLN(Convert.ToInt32(ps.Split('/')[0]), Convert.ToInt32(ps.Split('/')[1])) + "/" + Convert.ToInt32(ps.Split('/')[1]) / base.UCLN(Convert.ToInt32(ps.Split('/')[0]), Convert.ToInt32(ps.Split('/')[1]));
        }

        public string Cong(int c, int d)
        {
            int mau = d * b;
            int tu = mau / a + mau / b;
            return tu + "/" + mau;
        }

        public string Nhan(int c, int d)
        {
            int mau = a * c;
            int tu = b * d;
            return tu + "/" + mau;
        }

    }
}
